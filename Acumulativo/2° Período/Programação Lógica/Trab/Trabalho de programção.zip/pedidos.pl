:- dynamic pedido/7.


