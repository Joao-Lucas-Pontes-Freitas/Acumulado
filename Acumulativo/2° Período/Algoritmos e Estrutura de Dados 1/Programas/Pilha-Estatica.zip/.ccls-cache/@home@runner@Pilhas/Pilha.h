#define MAX 100 
typedef struct aluno{    
  int mat;    
  char nome[30];    
  float n1; 
} Aluno; 

typedef struct pilha Pilha;

Pilha *criar(); void limpar(Pilha *p);
int push(Pilha *p, Aluno it); 
int pop(Pilha *p, Aluno *it); 
int consultar(Pilha *p, Aluno *it); 
int tamanho(Pilha *p); int pilhaVazia(Pilha *p); 
int pilhaCheia(Pilha *p);